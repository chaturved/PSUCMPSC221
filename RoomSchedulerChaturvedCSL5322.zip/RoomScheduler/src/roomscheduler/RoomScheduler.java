
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package roomscheduler;
//import java.util.*;
//import java.sql.Date;
//import javax.swing.JFrame;

/**
 *
 * @author chaturvedsumanth
 */


public class RoomScheduler {

    /**
     * @param args the command line arguments
     **/
    public static void main(String[] args) {
        // TODO code application logic here
        
        //DBConnection dbconnection=new DBConnection();
        //ReservationQueries rq=new ReservationQueries(dbconnection);
        //WaitlistQueries wq=new WaitlistQueries(dbconnection);
        //long date=1606242600000L;
        //rq.addReservationEntry(new ReservationEntry("Chaturved","231", new Date(date), 18, new java.sql.Timestamp(Calendar.getInstance().getTime().getTime())));
        //System.out.println(rq.getRoomsReservedByDate(new Date(date)).get(0));
   
        //MainFrame roomscheduler=new MainFrame();
        //roomscheduler.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        //roomscheduler.setSize(350,300);
        //roomscheduler.setVisible(true);
        
    }   
    
}
